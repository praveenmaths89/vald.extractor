library(testthat)
library(vald.extractor)

test_check("vald.extractor")
